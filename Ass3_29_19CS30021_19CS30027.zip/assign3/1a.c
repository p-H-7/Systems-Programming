/*
    Assignment 3
    Haasita Pinnepu 19CS30021
    Majji Deepika 19CS30027
*/

#include<stdio.h>
#include<sys/ipc.h>
#include<sys/shm.h>
#include<sys/types.h>
#include<string.h>
#include<errno.h>
#include<stdlib.h>
#include<sys/stat.h>
#include<unistd.h>
#include<sys/wait.h>

#define BUF_SIZE 1024
#define SHM_KEY 0x1234

typedef struct _process_data 
{
    double **A;
    double **B;
    double **C;
    int veclen, i, j;
} ProcessData;

ProcessData *m;
int memory;
int pid;
int segment_id;
double *sh_mem;

void*mult(void *arg)
{   
    ProcessData *f=arg;
    
    
    int value=0;
    int x,y,z;

    for(x=0; x<(f->i);x++)
    {
        for(y=0; y<(f->j); y++)
        {
            for(z=0; z<(f->veclen); z++)
            {
                value=value+sh_mem[(f->veclen)*x+z]*sh_mem[(f->i)*(f->veclen)+(z*(f->j))+y];
            }
            printf("%d\n", value);
            sh_mem[(f->veclen)*((f->i)+(f->j))+(f->j)*x+y]=value;
            value=0;
        }
    }

    for(x=0; x<(f->i);x++)
    {
        for(y=0; y<(f->j); y++)
        {
            (m->C)[x][y]=sh_mem[(f->veclen)*((f->i)+(f->j))+(f->j)*x+y];
        } 
    }
     //printf("\nfun called\n");
     
     for(x=0; x<(f->i);x++)
    {
        for(y=0; y<(f->j); y++)
        {
            printf("%lf ",(m->C)[x][y]);
        } 
        printf("\n");
    }
}

int main()
{
   int r1,r2,c1,c2;
    int pid;
    int segment_id;
    int *shared_memory;
   printf("Enter no.of rows and columns of Matrix 1 \n");
   scanf("%d%d",&r1,&c1);
   printf("Enter no.of rows and columns of Matrix 2 \n");
   scanf("%d%d",&r2,&c2);

   if (c1!=r2)
   {
        printf("Matrix multiplication not possible \n");
        exit(0);
   }

    //printf("%d %d %d %d", r1,c1,r2,c2);
    
    m = (ProcessData *)malloc(sizeof(ProcessData));
    if(m==NULL)
    	printf("not working\n");

    (m->veclen)=r2;
    (m->i)=r1;
    (m->j)=c2;
    
    printf("\n Enter the elements of Matrix 1: \n");
    
    m->A=(double **)malloc(r1*sizeof(double*));
    //printf("Memory row\n");
    for(int x=0;x<r1;x++)
    {
        (m->A)[x]=(double *)malloc(c1*sizeof(double));
    }
    //printf("Memory done\n");

    for(int x=0;x<r1;x++)
    {
        for(int y=0;y<c1;y++)
        {
            scanf("%lf",&((m->A)[x][y])  );
        }
    }
    //printf("took input\n");
    
    printf("\nEnter the elements of Matrix 2: \n");
    
    m->B=(double **)malloc(r2*sizeof(double*));
    for(int x=0;x<r2;x++)
    {
        (m->B)[x]=(double *)malloc(c2*sizeof(double));
    }
    

    for(int x=0;x<r2;x++)
    {
        for(int y=0;y<c2;y++)
        {
            scanf("%lf",&((m->B)[x][y])  );
        }
    }
    
    m->C=(double **)malloc(r1*sizeof(double*));
    for(int x=0;x<r1;x++)
    {
          (m->C)[x]=(double *)malloc(c2*sizeof(double));
    }
    //printf("C done\n");
    
    //printf("C 2\n");

    memory=sizeof(double)*r1*r1*c2*r2*c1*c1;
    //printf("memory alloted\n");
    segment_id = shmget(IPC_PRIVATE,memory,S_IRUSR|S_IWUSR);
    //printf("segment_id done\n");
    sh_mem=(double *)shmat(segment_id,NULL,0);
    //printf("shmat done\n");
    for(int x=0;x<r1;x++)
         for(int y=0;y<c1;y++)
             sh_mem[x*c1+y]=(m->A)[x][y];
    //printf("loop done\n");
             
    for(int x=0;x<r1;x++)
         for(int y=0;y<c1;y++)
             printf("%lf ",sh_mem[x*c1+y]);
    //printf("loop 2 done\n");
    for(int x=0;x<r2;x++)
         for(int y=0;y<c2;y++)
             sh_mem[(r1*c1)+c2*x+y]=(m->B)[x][y];
     //printf("loop 3 done\n");
             
    pid=fork();
     //printf("forking done\n");
    if(pid==0)
    	mult(m);
    else if(pid>0)
    	wait(0);
    else 
    	printf("failed...\n");
    	return 1;

    

    //mult(m);
    return 0;
}