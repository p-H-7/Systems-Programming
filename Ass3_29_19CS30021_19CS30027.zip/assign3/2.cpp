/*
    Assignment 3
    Haasita Pinnepu 19CS30021
    Majji Deepika 19CS30027
*/

#include <fcntl.h>
#include <iostream>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include<time.h>
#include<signal.h>
#include <algorithm>
#include <cctype>
#include <fstream>
#include <functional>
#include <chrono>
//#include <bits/stdc++.h>
#include <locale>
#include <semaphore.h>
#include <string>

#include <vector>
using namespace std;
using namespace std::chrono;

#define endl "\n"
#define JMAX 8

int NP,NW,NMat;

struct job 
{
    int p_num;  //producer number
    int st;     //status of matrix multiplication
    int arr[100][100];   // matrix
    int m_id;   // matrix id


};
job create_job()
{	
	job j;
	
	j.p_num=(rand() % 100) + 1;
	j.st=0;
	j.m_id= rand()%(100000)+1;
	
	for(int i=0;i<100;i++)
	{
		for(int k=0;k<100;k++)
		{
			j.arr[i][k]=(rand() % 19)  - 9;
		}
	}
	
	return j;
}


void view(job *J)
{
    cout<<"producer number: "<<J->p_num<<endl;
    cout<<"status: "<<J->st<<endl;
    cout<<"matrix id: "<< J->m_id<<endl;
}

struct job_q
{
	job j_q[JMAX];
	int j_size;
	job_q():j_size(0){}
	
	bool is_full()
	{
		if(j_size == JMAX)
			return true;
		else 
			return false;
	}
	
	bool is_empty()
	{
		if(j_size == 0)
			return true;
		else 
			return false;
	}
	
	void insert(job j)
	{
		if((this->is_full()) ==  false)
		{
			j_q[j_size++] = j;
		} 
	}
	
	job top()
	{ 
		job Top = j_q[0];
		if((this->is_empty()) == false)
		{
		
		for (int i = 0 ; i < j_size - 1; i++)
		{
			j_q[i] = j_q[i+1];
		}
		j_size--;
		}
		return Top;
	}
};

struct shared_data
{
	int jobs_created;
	int jobs_finished;
	int jobs_total;
	job_q j_q;
	int c_status;
	int p_status;
	sem_t sem_consumer;
	sem_t sem_producer;

	void set()
	{
		jobs_created = 0;
		jobs_finished = 0;
		jobs_total = -1;
		j_q.set();
		c_status=0;
		p_status=0;
		sem_init(&sem_consumer, 1, 0);
		sem_init(&sem_producer, 1, 0);
	} 
	
};


int main()
{
    srand(time(NULL));
    time_t tstart,tend;

    cout<<"\n Enter the no.of producer processes:  \n";
    cin>>NP;

    cout<<"\n Enter the no.of worker processes :  \n";
    cin>>NW;

    cout<<"\n Enter the no.of matrices to be multiplied: \n";
    cin>>NMat;

    key_t key;
    //char* path="/dev/random";
    //int ID='a';
    
    time(&tstart);

    //key=ftok("/dev/random", 'a');
    int shmid = shmget(IPC_PRIVATE, 2048, 0666 | IPC_CREAT);
	shared_data *sh_dt = (shared_data *) shmat(shmid, (void *)0, 0);
	sh_dt->set();
	sh_dt->jobs_total = NMat;
	
	
	int num;
	for (num = 1; num <= NP; num++)
	{
		int pid = fork();
		if (pid==0){
			{
			while ((sh_dt->jobs_total) == -1);

			while ((sh_dt->jobs_created) < (sh_dt->jobs_total))
			{
				if ((sh_dt->j_q).is_full())	
				{	cout<<"queue is full\n";
					continue;
				}
				
				sem_wait(&(sh_dt->sem_producer));
				if ((sh_dt->jobs_created) < (sh_dt->jobs_total) and !((sh_dt->j_q).is_full()))
				{	
					sleep((rand() % 4));
					
					int job_id = (sh_dt->jobs_created)++;
					job j_created = create_job();

					cout << "Producer " << num << " created matrix " << j_created.m_id << endl;
					view(&j_created);
					cout<<endl;

					(sh_dt->j_q).insert(j_created);
				}
				sem_post(&(sh_dt->sem_producer));
			}
			shmdt(sh_dt);
			exit(0);
			}
			break;
		} 
	} 
	
	int con_num;
	for(con_num=1;con_num<=NW;con_num++)
	{	int pid=fork();
		if(pid==0)
		{
			while ((sh_dt->jobs_total) == -1);
			while ((sh_dt->jobs_finished) < (sh_dt->jobs_total))
			{	
				if ((sh_dt->j_q).is_empty())	
					continue;	
			}
			
			
			int m1[100][100]=(sh_dt->j_q).top();
			int m2[100][100]=(sh_dt->j_q).top();
			
			int m3[100][100];
			
			for(int i=0; i<100; i++)
				{
					for(int j=0; j<100; j++)
					{
						int sum=0;
						for(int k=0; k<100; k++)
						sum = sum + m1[i][k] * m2[k][j];
						m3[i][j] = sum;
					}
				}
		
        }
	}

	sem_wait&((sh_dt->sem_consumer));
	sleep(rand()%4);


	time(&tend);
    shmdt(sd_dt);
    shmctl(shmid, IPC_RMID, NULL);
    exit(0);
}
		